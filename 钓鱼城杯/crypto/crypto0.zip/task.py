# !/usr/bin/env python3
import socketserver
import os
from Crypto.Cipher import AES
from Crypto.Util import number

from secret import flag
flag = flag.encode()
assert len(flag) == 48

MENU = br"""
1. encrypt
2. hint
3. exit
"""

class Task(socketserver.BaseRequestHandler):
    def _recvall(self):
        BUFF_SIZE = 2048
        data = b''
        while True:
            part = self.request.recv(BUFF_SIZE)
            data += part
            if len(part) < BUFF_SIZE:
                break
        return data.strip()

    def send(self, msg, newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def recv(self, prompt=b'> '):
        self.send(prompt, newline=False)
        return self._recvall()

    def recvhex(self, prompt=b'> '):
        self.send(prompt, newline=False)
        try:
            data = bytes.fromhex(self._recvall().decode('latin-1'))
        except ValueError as e:
            self.send(b"Wrong hex value!")
            self.close()
            return None
        return data

    def close(self):
        self.send(b"Bye~")
        self.request.close()

    def pad(self, data):
        pad_len = 16 - len(data)%16
        return data + bytes([pad_len])*pad_len

    def handle(self):
        key = os.urandom(16)
        IV = os.urandom(16)
        padding = os.urandom(160)
        aes = AES.new(key, mode=AES.MODE_CBC, IV=IV)

        p = number.getPrime(1024)
        q = number.getPrime(1024)
        n = p * q

        cnt = 0

        while True:
            self.send(MENU, newline=False)
            choice = self.recv()

            if choice == b"1":
                if cnt < 20000:
                    msg = self.recvhex(prompt=b"Your message (in hex): ")
                    if not msg: break
                    cipher = aes.encrypt(self.pad(msg + flag + padding))
                    self.send(cipher.hex().encode())
                    cnt += 1
                continue
            elif choice == b"2":
                tmp = number.bytes_to_long(flag + padding)
                msg = number.long_to_bytes(pow(tmp, 3, n)).hex().encode()
                self.send("n = {}".format(n).encode())
                self.send(msg)
                continue

            self.close()
            break

class ThreadedServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass

class ForkedServer(socketserver.ForkingMixIn, socketserver.TCPServer):
    pass

if __name__ == "__main__":
    HOST, PORT = '0.0.0.0', 23333
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()