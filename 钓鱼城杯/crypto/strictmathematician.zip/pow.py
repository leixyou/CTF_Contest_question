def pow(difficult=8):
    if difficult>256:
        difficult=256
    salt=os.urandom(16)
    #print("[+]pow: "+'sha256 ( nonce +', salt.hex(), ') ==', '0' * difficult, '...')
    print("[+]pow: "+ "bin(int(sha256(nonce+"+'\"'+'{}'.format(salt.hex())+'")'+".hexdigest(),16)).endswith: {}".format('0'*difficult))
    nonce=input('[-]nonce in hex (without "0x"):')
    tmp=bin(int(hashlib.sha256(long_to_bytes(int(nonce,16))+salt).hexdigest(),16))[2:]
    if tmp.endswith("0"*difficult):
        return True
    else:
        return False
